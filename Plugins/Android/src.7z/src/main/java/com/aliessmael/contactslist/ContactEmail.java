package com.aliessmael.contactslist;

/**
 * Created by User on 11/23/2015.
 */
public class ContactEmail {
    String Address;
    String Type;
}
