package com.cloudsoft.contactslist;

import java.util.List;



public class ContactListItem {
	String 			idContact 	;
	String 			name 		;
	boolean      	phonesInitialized = false;
	List<String> 	phoneNumbers ;
	List<String> 	phoneTypes ;
	boolean      	emailsInitialized = false;
	List<String> 	emails ;
	boolean   		photoInitialized = false;
    String 			photo 		;
    boolean 		connectionInitialized = false;
    List<String>	connections ;
    
}
 