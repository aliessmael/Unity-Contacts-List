package com.cloudsoft.contactslist;
import java.util.ArrayList;
import java.util.List;

import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;


import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;



public class ContactList {
	static String myNumber ;
	static String simSerialNumber ;
	static String networkOperator ;
	static String networkCountryIso ;
	static void fillSimInfo( Activity activity ){
	    TelephonyManager mTelephonyMgr = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE); 
	    myNumber = mTelephonyMgr.getLine1Number();
	    simSerialNumber = mTelephonyMgr.getSimSerialNumber();
	    networkOperator = mTelephonyMgr.getNetworkOperator();
	    networkCountryIso = mTelephonyMgr.getNetworkCountryIso();
	}
	public static String GetSimSerialNumber()
	{
		return simSerialNumber ;
	}
	public static String GetNetworkOperator()
	{
		return networkOperator ;
	}
	public static String GetNetworkCountryIso()
	{
		return networkCountryIso ;
	}
	public static String GetMyPhoneNumber()
	{
		return myNumber ;
	}
	public static String GetContactId( int id )
	{
		try {
			return contactList.get(id).idContact ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	public static String GetContactName( int id )
	{
		try {
			return contactList.get(id).name ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	public static int GetEmailsCount( int id )
	{
		try {
			ContactListItem item =  contactList.get(id) ;
			if( item.emailsInitialized == false )
	        {
	            Cursor cur1 = cr.query( 
	                    ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
	                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",  new String[]{item.idContact}, null); 
	            while (cur1.moveToNext()) { 
	               
	                String email = cur1.getString(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
	                //if( !item.emails.contains(email))
	                	item.emails.add( email );
	               
	            } 
	            cur1.close();
	            item.emailsInitialized = true ;
	        }
			return contactList.get(id).emails.size();
		} catch (Exception e) {
			logException( e);
	    	return 0;
		}
	}
	public static String GetEmail( int id , int emailId )
	{
		try {
			ContactListItem item =  contactList.get(id) ;
			return item.emails.get(emailId) ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	public static int GetContactNumberCount( int id )
	{
		try {
			ContactListItem item =  contactList.get(id) ;
			 if( item.phonesInitialized == false )
	        {
	           Cursor cur1 = cr.query( 
	        		   ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
	        		   ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",  new String[]{item.idContact}, null); 
	           while (cur1.moveToNext()) { 
	              
	               String phone = cur1.getString(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
	              
	               if( phone != null )
	               {
	               		item.phoneNumbers.add( phone );
	               		
	               		int phoneTypeId = cur1.getInt(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE));
	               		String phoneType = (String)ContactsContract.CommonDataKinds.Phone.getTypeLabel(activity.getResources(), phoneTypeId , "Mobile");
	               		if( phoneType.equals("Custom") )
	               			phoneType = cur1.getString(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LABEL));
	               		item.phoneTypes.add( phoneType );
	               }
	               else 
	               {
	            	   break;
	               }
	              
	           } 
	           cur1.close();
	           item.phonesInitialized = true ;
	        }
			return contactList.get(id).phoneNumbers.size();
		} catch (Exception e) {
			logException( e);
	    	return 0;
		}
	}
	public static String GetContactNumber( int id , int phoneId )
	{
		try {
			return contactList.get(id).phoneNumbers.get(phoneId) ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	public static String GetContactNumberType( int id , int phoneId )
	{
		try {
			return contactList.get(id).phoneTypes.get(phoneId) ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	public static String GetContactPhoto( int id )
	{
		try {
			ContactListItem item =  contactList.get(id) ;
			if( item.photoInitialized == false )
	        {
	            byte[] p = getPhoto( item );	
	            if( p == null )
	            	item.photo = "";
	            else 
	            	 item.photo = Base64.encodeToString(p, Base64.DEFAULT);
	            
	            item.photoInitialized = true ;
	        }
			return item.photo ;
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	
	public static int GetContactConnectionsCount( int id )
	{
		try {
			ContactListItem item =  contactList.get(id) ;
			if( item.connectionInitialized == false )
			{
				Cursor cc = null;
		        try {
	
		             cc = cr.query(ContactsContract.RawContacts.CONTENT_URI,
		                     new String[]{ContactsContract.RawContacts.ACCOUNT_NAME},
		                     ContactsContract.RawContacts.CONTACT_ID +"=?",
		                     new String[]{item.idContact},
		                     null);
	
		            if (cc != null && cc.getCount() >0)
		            {
		            	while (cc.moveToNext()) { 
			                String connection = cc.getString(cc.getColumnIndex(ContactsContract.RawContacts.ACCOUNT_NAME));
			                item.connections.add(connection) ;
		            	}
		                cc.close();
		            }
		        } catch (Exception e) {
		        	logException( e);
		        } finally{
		          cc.close();
		        }
		        item.connectionInitialized = true;
			}
			return contactList.get(id).connections.size() ;
		} catch (Exception e) {
			logException( e);
	    	return 0;
		}
	}
	public static String GetContactConnection( int id , int connectionId)
	{
		try {
			return contactList.get(id).connections.get(connectionId);
		} catch (Exception e) {
			logException( e);
	    	return "";
		}
	}
	
	public static int GetContactsCount()
	{
		try {
			return contactList.size() ;
		} catch (Exception e) {
			logException( e);
	    	return 0;
		}
	}

	private static List<ContactListItem> contactList = null;
	
	static ContactListItem getContact( String idContact )
	{
		try {
			for( int i = 0 ; i < contactList.size() ; i++ ){
				if( contactList.get(i).idContact.equals( idContact ))
					return contactList.get(i);
			}
			return null ;
		} catch (Exception e) {
			logException( e);
	    	return null;
		}
	}
	static ContentResolver cr = null;
	static Activity activity;
	public static void LoadInformation( Activity _activity )
	{
		activity = _activity;
		fillSimInfo(activity);
		
		contactList = new ArrayList<ContactListItem>();
		Cursor cc = null;
	    try {
	    	 cr = activity.getContentResolver() ;
	    	 String[] projection =
	    	 {
	    	     ContactsContract.Contacts._ID,   
	    	     ContactsContract.Contacts.DISPLAY_NAME,
	    	 };
	    	 String sortOrder = ContactsContract.Contacts.DISPLAY_NAME + " COLLATE LOCALIZED ASC";
	    	 cc = cr.query( ContactsContract.Contacts.CONTENT_URI,projection,null,null, sortOrder);
	    	 if(cc.getCount()>0){
	    	
		         while (cc.moveToNext())
		         {
		        	String idContact = cc.getString(cc.getColumnIndex(ContactsContract.Contacts._ID));
		        	
		        	ContactListItem item = getContact( idContact );
		        	if( item == null )
		        	{
		        		String name = cc.getString(cc.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
			        	
		        		item = new ContactListItem();
		        		item.idContact	 =  idContact ;
		        		item.name = name ;
		        		item.phoneNumbers = new ArrayList<String>();
		        		item.emails = new ArrayList<String>();
		        		item.phoneTypes = new ArrayList<String>();
		        		item.connections = new ArrayList<String>(); 
		        		contactList.add(item);
		        	}
		         }
	    	 }
	    } catch (Exception e) {
	    	logException( e);
	    } finally {
	        if (cc != null) {
	            cc.close();
	        }
	    }

	}
	
	static byte[] getPhoto( ContactListItem item ) {
		try {
			long contactId = Long.parseLong( item.idContact ); 
			Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId);
	        Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
	        Cursor cursor = cr.query(photoUri,
	                new String[] {ContactsContract.CommonDataKinds.Photo.PHOTO}, null, null, null);
	        if (cursor == null) {
	            return null;
	        }
	        try {
	            if (cursor.moveToFirst()) {
	                byte[] data = cursor.getBlob(0);
	                if (data != null) {
	                    return data ;
	                }
	            }
	        } finally {
	            cursor.close();
	        }
	        return null;
		} catch (Exception e) {
			logException( e);
	    	return null;
		}
	 }
	
	static void logException( Exception e )
	{
		String message = Log.getStackTraceString( e);
		UnityPlayer.UnitySendMessage("ContactsListMessageReceiver","Error",message);
		e.printStackTrace();
	}
}
