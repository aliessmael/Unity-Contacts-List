package com.aliessmael.contactslist;

import java.util.List;


public class Contact {

	String 				Id 	;
	String 				Name ;

	boolean   			photoInitialized = false;
	byte[] 				Photo 		;

    List<ContactPhone> 	Phones ;
	List<ContactEmail> 	Emails;
	List<String>	   	Connections ;

}

